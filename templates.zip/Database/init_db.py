"""
Run this ONCE to create all tables and seed the question banks.
    python init_db.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db import get_db_connection

conn = get_db_connection()

# STUDENTS
conn.execute("""
CREATE TABLE IF NOT EXISTS students (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    email      TEXT    UNIQUE NOT NULL,
    password   TEXT    NOT NULL,
    department TEXT    NOT NULL
)
""")

# ── VIOLATIONS ────────────────────────────────────────────────
conn.execute("""
CREATE TABLE IF NOT EXISTS violations (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id     INTEGER NOT NULL,
    violation_type TEXT    NOT NULL,
    timestamp      DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(student_id) REFERENCES students(id)
)
""")

# ── LOGIN LOGS ────────────────────────────────────────────────
conn.execute("""
CREATE TABLE IF NOT EXISTS login_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(student_id) REFERENCES students(id)
)
""")

# ── EXAM ATTEMPTS ─────────────────────────────────────────────
conn.execute("""
CREATE TABLE IF NOT EXISTS exam_attempts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id   INTEGER NOT NULL,
    subject      TEXT    NOT NULL,
    started_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    submitted_at DATETIME,
    score        INTEGER DEFAULT 0,
    total        INTEGER DEFAULT 0,
    FOREIGN KEY(student_id) REFERENCES students(id)
)
""")

# ── QUESTIONS ─────────────────────────────────────────────────
conn.execute("""
CREATE TABLE IF NOT EXISTS questions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    subject        TEXT NOT NULL,
    question       TEXT NOT NULL,
    option_a       TEXT NOT NULL,
    option_b       TEXT NOT NULL,
    option_c       TEXT NOT NULL,
    option_d       TEXT NOT NULL,
    correct_answer TEXT NOT NULL
)
""")

conn.commit()

# ── SEED QUESTIONS (only if table is empty) ───────────────────
existing = conn.execute("SELECT COUNT(*) FROM questions").fetchone()[0]
if existing == 0:

    it_questions = [
        ("IT","What does CPU stand for?",
         "Central Processing Unit","Computer Processing Unit",
         "Central Program Unit","Control Processing Unit","A"),
        ("IT","Which language runs natively in a web browser?",
         "Python","Java","JavaScript","C++","C"),
        ("IT","What does RAM stand for?",
         "Read Access Memory","Random Access Memory",
         "Rapid Action Memory","Random Application Memory","B"),
        ("IT","Which protocol is used to send emails?",
         "FTP","HTTP","SMTP","SSH","C"),
        ("IT","What is the base of the binary number system?",
         "8","10","2","16","C"),
        ("IT","Which device connects two different networks?",
         "Switch","Hub","Router","Repeater","C"),
        ("IT","What does HTML stand for?",
         "Hyper Text Markup Language","High Text Markup Language",
         "Hyper Transfer Markup Language","Hyper Text Machine Language","A"),
        ("IT","Which of the following is NOT an operating system?",
         "Linux","Windows","Oracle","macOS","C"),
        ("IT","What does URL stand for?",
         "Uniform Resource Locator","Universal Resource Link",
         "Uniform Routing Language","Universal Routing Locator","A"),
        ("IT","Which layer of the OSI model handles routing?",
         "Data Link","Transport","Network","Session","C"),
        ("IT","What is the full form of DNS?",
         "Domain Name System","Dynamic Name Server",
         "Distributed Network Service","Digital Naming Standard","A"),
        ("IT","A byte is made up of how many bits?",
         "4","16","32","8","D"),
        ("IT","Which sorting algorithm has average time complexity O(n log n)?",
         "Bubble Sort","Insertion Sort","Merge Sort","Selection Sort","C"),
        ("IT","What does SQL stand for?",
         "Structured Query Language","Standard Query Language",
         "Sequential Query Language","Simple Query Language","A"),
        ("IT","Which data structure uses LIFO order?",
         "Queue","Stack","Array","Tree","B"),
        ("IT","IPv4 addresses are how many bits long?",
         "16","64","128","32","D"),
        ("IT","What is the default port for HTTPS?",
         "80","21","443","8080","C"),
        ("IT","Which of these is a NoSQL database?",
         "MySQL","PostgreSQL","MongoDB","SQLite","C"),
        ("IT","What does an IP address identify?",
         "A website domain","A device on a network",
         "A file on a server","A user's identity","B"),
        ("IT","Which Python keyword is used to define a function?",
         "func","def","function","define","B"),
        ("IT","What does GUI stand for?",
         "General User Interface","Graphical User Interface",
         "Global Utility Interface","Graphical Utility Input","B"),
        ("IT","What is the purpose of a firewall?",
         "Speed up internet","Monitor disk usage",
         "Control network traffic","Compress files","C"),
        ("IT","Which file extension is used for Python scripts?",
         ".java",".py",".cpp",".rb","B"),
        ("IT","What does VPN stand for?",
         "Virtual Private Network","Very Private Node",
         "Variable Packet Network","Verified Private Node","A"),
        ("IT","Which search algorithm requires a sorted list?",
         "Linear Search","Binary Search","Jump Search (unsorted)","All of these","B"),
        ("IT","What is the output of 5 % 2 in Python?",
         "2","2.5","0","1","D"),
        ("IT","CSS stands for?",
         "Computer Style Sheets","Creative Style System",
         "Cascading Style Sheets","Cascading System Script","C"),
        ("IT","What does API stand for?",
         "Application Programming Interface","Applied Program Interface",
         "Application Process Input","Automated Program Interface","A"),
        ("IT","Which component stores the OS and files permanently?",
         "RAM","Cache","ROM","Hard Disk","D"),
        ("IT","What is a primary key in a database?",
         "A foreign reference","A unique identifier for each row",
         "An encrypted column","A duplicate-allowed column","B"),
    ]

    electronics_questions = [
        ("Electronics","What is Ohm's Law?",
         "V = IR","P = IV","V = P/I","I = PV","A"),
        ("Electronics","What does a capacitor store?",
         "Charge","Magnetic flux","Current","Resistance","A"),
        ("Electronics","What is the unit of resistance?",
         "Ampere","Volt","Ohm","Watt","C"),
        ("Electronics","Which component allows current in one direction only?",
         "Resistor","Capacitor","Transistor","Diode","D"),
        ("Electronics","What is the SI unit of capacitance?",
         "Henry","Ohm","Farad","Tesla","C"),
        ("Electronics","What does BJT stand for?",
         "Bipolar Junction Transistor","Binary Junction Transfer",
         "Basic Junction Transistor","Bipolar Joined Terminal","A"),
        ("Electronics","Which logic gate outputs 1 only when all inputs are 1?",
         "OR","NAND","AND","NOR","C"),
        ("Electronics","What is the unit of frequency?",
         "Watt","Hertz","Joule","Tesla","B"),
        ("Electronics","What does LED stand for?",
         "Light Emitting Diode","Low Energy Device",
         "Linear Electronic Device","Light Energy Detector","A"),
        ("Electronics","A transformer is used to?",
         "Convert AC to DC","Store electrical energy",
         "Step up or step down AC voltage","Generate current","C"),
        ("Electronics","What is the output of a NOT gate when input is 0?",
         "0","Undefined","1","High Impedance","C"),
        ("Electronics","Kirchhoff's Voltage Law states?",
         "Sum of currents at a node is zero",
         "Sum of voltages in a closed loop is zero",
         "Power equals voltage times current",
         "Resistance equals voltage divided by current","B"),
        ("Electronics","What is the gain of an op-amp in open loop ideally?",
         "1","Finite","Zero","Infinite","D"),
        ("Electronics","Which semiconductor material is most commonly used?",
         "Germanium","Silicon","Carbon","Gallium Arsenide","B"),
        ("Electronics","What does ADC stand for in electronics?",
         "Analog to Digital Converter","Automated Data Control",
         "Analog Data Circuit","Advanced Digital Component","A"),
        ("Electronics","In a series circuit, current is?",
         "Different at each component","Zero","Same throughout","Divided equally","C"),
        ("Electronics","What is a flip-flop used for?",
         "Amplifying signals","Storing one bit of data",
         "Converting voltage","Generating frequency","B"),
        ("Electronics","What is the function of a zener diode?",
         "Amplification","Rectification",
         "Voltage regulation","Oscillation","C"),
        ("Electronics","Which filter allows only low frequencies to pass?",
         "High Pass Filter","Band Pass Filter",
         "Band Stop Filter","Low Pass Filter","D"),
        ("Electronics","What is the colour code for a 100 ohm resistor?",
         "Brown Black Brown","Red Red Red",
         "Brown Black Orange","Red Black Brown","A"),
        ("Electronics","MOSFET stands for?",
         "Metal Oxide Semiconductor Field Effect Transistor",
         "Multi Output Signal Field Effect Transfer",
         "Metal On Silicon Field Effect Terminal",
         "Modulated Output Semiconductor Field Effect Transistor","A"),
        ("Electronics","What is the unit of inductance?",
         "Farad","Ohm","Tesla","Henry","D"),
        ("Electronics","What is the truth table output of XOR when both inputs are 1?",
         "1","Undefined","High","0","D"),
        ("Electronics","Which device converts mechanical energy to electrical energy?",
         "Motor","Transformer","Generator","Inverter","C"),
        ("Electronics","A full-wave rectifier uses how many diodes?",
         "1","3","4","2","D"),
        ("Electronics","What is the purpose of a bypass capacitor?",
         "Increase resistance","Block DC signals",
         "Filter high-frequency noise","Store charge permanently","C"),
        ("Electronics","Binary number 1010 in decimal is?",
         "8","12","10","9","C"),
        ("Electronics","The bandwidth of an amplifier is measured between?",
         "Half power points (−3 dB)","Zero crossing points",
         "Peak power points","DC offset points","A"),
        ("Electronics","Which component is used to protect circuits from excess current?",
         "Resistor","Capacitor","Fuse","Inductor","C"),
        ("Electronics","What does PWM stand for?",
         "Pulse Width Modulation","Power Wave Management",
         "Phase Width Modulation","Pulse Wave Multiplier","A"),
    ]

    conn.executemany(
        "INSERT INTO questions (subject,question,option_a,option_b,option_c,option_d,correct_answer) "
        "VALUES (?,?,?,?,?,?,?)",
        it_questions + electronics_questions
    )
    conn.commit()
    print(f"  Seeded {len(it_questions)} IT questions and {len(electronics_questions)} Electronics questions.")
else:
    print(f"  Questions table already has {existing} rows — skipping seed.")

conn.close()
print("Database setup complete → students.db")