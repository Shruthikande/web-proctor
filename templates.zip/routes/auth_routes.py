from flask import request, redirect, url_for, render_template
from Database.db import get_db_connection   # db.py is at the project root

def register():
    # GET request → just show the registration page
    if request.method == "GET":
        return render_template("Register.html")

    # POST request → read form fields and save to DB
    name       = request.form.get("name", "").strip()
    email      = request.form.get("email", "").strip().lower()
    password   = request.form.get("password", "")
    department = request.form.get("department", "")

    # Basic validation
    if not name or not email or not password or not department:
        return render_template("Register.html",
                            error="All fields are required.")

    conn = get_db_connection()

    # Check if email already registered
    existing = conn.execute(
        "SELECT id FROM students WHERE email=?", (email,)
    ).fetchone()

    if existing:
        conn.close()
        return render_template("Register.html",
                            error="This email is already registered. Please login.")

    conn.execute(
        "INSERT INTO students (name, email, password, department) VALUES (?, ?, ?, ?)",
        (name, email, password, department)
    )
    conn.commit()
    conn.close()

    return render_template("Register.html",
                           success="Registration successful! You can now login.")