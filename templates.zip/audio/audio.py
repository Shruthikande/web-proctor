import sounddevice as sd
import numpy as np
import time
import os
import shared

# TUNING CONSTANTS
SAMPLERATE     = 44100
CHANNELS       = 1
BLOCK_SIZE     = 2048        # frames per callback (~46 ms at 44100 Hz)

# Volume threshold — raise if mic picks up too much background noise
VOLUME_THRESHOLD = 6

# Human voice frequency range: 85 Hz – 3000 Hz. fan keyboard will be sitting and low.
VOICE_FREQ_LOW  = 85
VOICE_FREQ_HIGH = 3000

# How much of the detected energy must be in the voice band to count
# as a human speaking (vs general noise), 30% of energy in speech band = likely talking
VOICE_RATIO_MIN = 0.30       

# Consecutive loud+voice frames needed before raising an alert
CONFIRM_FRAMES = 3
ALERT_GAP      = 3           # seconds between repeated alerts

os.makedirs("static/evidence", exist_ok=True)
log_path = "static/evidence/audio_log.txt"

# STATE (module-level, accessed inside callback) ───────────
noise_count          = 0
last_alert           = 0
_on_talking_detected = None


# ══════════════════════════════════════════════════════════════
#  is_human_voice()
#  Uses a Fast Fourier Transform (FFT) to break the audio block
#  into its individual frequency components.
#  Steps:
#  1. Compute FFT → array of complex numbers (one per frequency)
#  2. Take absolute value → amplitude at each frequency
#  3. Sum amplitudes in the human voice band (85–3000 Hz)
#  4. Divide by total amplitude → voice_ratio
#  If voice_ratio >= VOICE_RATIO_MIN we classify it as speech.
# ══════════════════════════════════════════════════════════════

def is_human_voice(audio_block: np.ndarray) -> tuple[bool, float]:
    """
    Returns (is_voice: bool, voice_ratio: float 0-1).
    audio_block should be a 1-D float32 array.
    """
    if len(audio_block) < 2:
        return False, 0.0

    fft_vals  = np.abs(np.fft.rfft(audio_block))
    freqs     = np.fft.rfftfreq(len(audio_block), d=1.0 / SAMPLERATE)

    total_energy = np.sum(fft_vals) + 1e-9   # avoid div/0

    # Mask for the voice frequency band
    voice_mask  = (freqs >= VOICE_FREQ_LOW) & (freqs <= VOICE_FREQ_HIGH)
    voice_energy = np.sum(fft_vals[voice_mask])

    voice_ratio = voice_energy / total_energy
    return voice_ratio >= VOICE_RATIO_MIN, float(voice_ratio)


# ══════════════════════════════════════════════════════════════
#  AUDIO CALLBACK
#  sounddevice calls this function every BLOCK_SIZE frames.
#  We check volume AND human-voice ratio before counting a hit.
# ══════════════════════════════════════════════════════════════

def audio_callback(indata, frames, time_info, status):
    global noise_count, last_alert

    if status:
        print(f"  Audio status: {status}")

    mono_block = indata[:, 0].astype(np.float32)
    volume     = float(np.linalg.norm(mono_block) * 10)
    print(f"  Volume: {int(volume):3d}   ", end="\r")

    if volume > VOLUME_THRESHOLD:
        voice_detected, voice_ratio = is_human_voice(mono_block)

        if voice_detected:
            noise_count += 1
            print(f"  Volume: {int(volume):3d}  voice_ratio={voice_ratio:.2f}  frames={noise_count}   ", end="\r")
        else:
            # Loud but not speech (fan, keyboard, etc.) — slowly decay
            noise_count = max(0, noise_count - 1)
    else:
        noise_count = 0

    if noise_count >= CONFIRM_FRAMES:
        now = time.time()
        if now - last_alert >= ALERT_GAP:
            last_alert  = now
            noise_count = 0
            print(f"\n  [{time.ctime()}] Human talking detected!")

            # ── ADD WARNING TO SHARED COUNTER ─────────────────
            with shared.warning_lock:
                shared.warning_count += 1
                shared.warning_messages.append({
                    "type":    "talking_detected",
                    "message": "Human talking detected!",
                    "count":   shared.warning_count,
                    "time":    time.strftime("%H:%M:%S"),
                })
            print(f"  WARNING [{shared.warning_count}/5] — talking_detected")
            # ──────────────────────────────────────────────────

            try:
                with open(log_path, "a", encoding="utf-8") as f:
                    f.write(f"{time.ctime()} - Human talking detected\n")
            except Exception as e:
                print(f"  Log error: {e}")

            if _on_talking_detected:
                try:
                    _on_talking_detected({"type": "talking", "timestamp": now})
                except Exception:
                    pass


# ══════════════════════════════════════════════════════════════
#  PUBLIC API — called by app.py in a background thread
# ══════════════════════════════════════════════════════════════

def start_audio_monitoring(stop_event=None, on_talking_detected=None):
    global _on_talking_detected
    _on_talking_detected = on_talking_detected

    print("  Audio monitoring started (human voice detection active).")
    print(f"  Voice band: {VOICE_FREQ_LOW}–{VOICE_FREQ_HIGH} Hz  |  "
        f"ratio threshold: {VOICE_RATIO_MIN:.0%}")

    with sd.InputStream(callback=audio_callback, channels=CHANNELS,
                        samplerate=SAMPLERATE, blocksize=BLOCK_SIZE,
                        device=None):
        while True:
            if stop_event and stop_event.is_set():
                break
            time.sleep(0.1)


if __name__ == "__main__":
    print("Running audio monitor standalone (Ctrl+C to stop)...")
    start_audio_monitoring()
