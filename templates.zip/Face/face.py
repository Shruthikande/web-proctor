import cv2
import mediapipe as mp
import numpy as np
from scipy.linalg import inv
from ultralytics import YOLO
import threading
from queue import Queue, Empty
import time
import os
import queue as queue_module
import shared   # memory bridge to Flask

CAMERA_INDEX              = 0
MODEL_NAME                = "yolov8n.pt"
IMAGE_SIZE                = 320
MIN_CONFIDENCE_THRESHOLD  = 0.05
BUFFER_FRAMES             = 3
EVIDENCE_DIR              = os.path.join("static", "evidence")
NO_FACE_THRESHOLD         = 4
MULTI_FACE_ALERT_FRAMES   = 5

# ── GAZE TRACKING ─────────────────────────────────────────────
# Iris landmark indices in MediaPipe FaceMesh (refine_landmarks=True)
# Left iris: 468-472, Right iris: 473-477
LEFT_IRIS   = [468, 469, 470, 471, 472]
RIGHT_IRIS  = [473, 474, 475, 476, 477]
# Eye corner landmark indices for normalising gaze direction
LEFT_EYE_CORNERS  = [33, 133]   # inner and outer corners
RIGHT_EYE_CORNERS = [362, 263]
# How many consecutive off-screen frames before a gaze warning
GAZE_AWAY_THRESHOLD = 20        # ~2 seconds at 10 fps

ALLOWED_OBJECTS = {
    "person":     0.80,
    "cell phone": 0.40,   # lowered slightly for better phone detection
    "bottle":     0.05,
    "laptop":     0.75,   # slightly relaxed
    "mouse":      0.10,
    "book":       0.35,   # slightly relaxed
    "earphone":   0.40,   # added: detect earphones/earbuds
}

DISPLAY_NAMES = {
    "bottle":   "BOTTLE/FLASK",
    "book":     "BOOK",
    "laptop":   "LAPTOP",
    "earphone": "EARPHONE",
}

OBJ_COLORS = {
    "cell phone": (0, 0, 255),
    "laptop":     (0, 0, 255),
    "book":       (0, 0, 255),
    "earphone":   (0, 165, 255),
    "default":    (0, 255, 0),
    "person":     (0, 0, 255),
    "bottle":     (0, 255, 0),
}


# ══════════════════════════════════════════════════════════════
#  GAZE TRACKER
#  Uses MediaPipe iris landmarks to estimate where the student
#  is looking. If they look away from the screen for too many
#  consecutive frames a warning is raised.
#
#  How it works:
#  - The iris centre x position is compared to the eye corners.
#  - A ratio near 0.5 means looking straight ahead (at screen).
#  - Ratio near 0 → looking left, ratio near 1 → looking right.
#  - We also check vertical (y) ratio for looking up/down.
# ══════════════════════════════════════════════════════════════

class GazeTracker:
    def __init__(self):
        self.gaze_away_counter = 0
        self.last_gaze_dir = "forward"

    def estimate(self, face_landmarks, fw, fh):
        """
        Returns (gaze_direction_string, is_looking_away).
        face_landmarks: a single FaceMesh landmark object.
        """
        lms = face_landmarks.landmark

        # ── Left iris centre ──────────────────────────────────
        lx = sum(lms[i].x for i in LEFT_IRIS)  / len(LEFT_IRIS)
        ly = sum(lms[i].y for i in LEFT_IRIS)  / len(LEFT_IRIS)

        # ── Right iris centre ─────────────────────────────────
        rx = sum(lms[i].x for i in RIGHT_IRIS) / len(RIGHT_IRIS)
        ry = sum(lms[i].y for i in RIGHT_IRIS) / len(RIGHT_IRIS)

        avg_iris_x = (lx + rx) / 2
        avg_iris_y = (ly + ry) / 2

        # ── Eye bounding box for normalisation ────────────────
        l_inner = lms[LEFT_EYE_CORNERS[0]]
        l_outer = lms[LEFT_EYE_CORNERS[1]]
        r_inner = lms[RIGHT_EYE_CORNERS[0]]
        r_outer = lms[RIGHT_EYE_CORNERS[1]]

        eye_left  = min(l_outer.x, r_outer.x)
        eye_right = max(l_inner.x, r_inner.x)
        eye_width = max(eye_right - eye_left, 1e-5)

        # Normalised horizontal ratio: 0=far left, 0.5=centre, 1=far right
        h_ratio = (avg_iris_x - eye_left) / eye_width

        # Vertical: simple check (looking up = low y value in image coords)
        v_ratio = avg_iris_y   # normalised 0–1, 0 is top of image

        # ── Classify direction ────────────────────────────────
        if h_ratio < 0.35:
            direction = "left"
        elif h_ratio > 0.65:
            direction = "right"
        elif v_ratio < 0.25:
            direction = "up"
        elif v_ratio > 0.75:
            direction = "down"
        else:
            direction = "forward"

        looking_away = (direction != "forward")
        self.last_gaze_dir = direction
        return direction, looking_away


# ══════════════════════════════════════════════════════════════
#  STEEL BOTTLE DETECTOR
#  Checks HSV saturation/brightness to distinguish steel from
#  plastic bottles (plastic is more colourful → higher sat).
# ══════════════════════════════════════════════════════════════

def steel_bottle(frame, x1, y1, x2, y2) -> bool:
    roi = frame[y1:y2, x1:x2]
    if roi.size == 0:
        return False
    hsv     = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    avg_sat = float(np.mean(hsv[:, :, 1]))
    avg_bri = float(np.mean(hsv[:, :, 2]))
    return avg_sat < 60 and avg_bri > 80


# ══════════════════════════════════════════════════════════════
#  NON-MAXIMUM SUPPRESSION  (custom, per-class)
#
#  WHY: YOLO sometimes fires 2-3 overlapping boxes for the same
#  object (e.g. a phone detected as both "cell phone" at 0.7
#  and again at 0.4 slightly shifted). Without NMS, both boxes
#  trigger separate warnings and evidence saves.
#
#  HOW: For each class label, sort detections by confidence
#  descending. Keep the top box; suppress any other box whose
#  IoU with the kept box exceeds NMS_IOU_THRESHOLD.
#  IoU (Intersection over Union) = overlap_area / union_area.
#  A threshold of 0.4 means "if two boxes share more than 40%
#  of their combined area, they're the same object."
# ══════════════════════════════════════════════════════════════

NMS_IOU_THRESHOLD = 0.40   # suppress boxes with IoU > this

def _iou(boxA, boxB):
    """Compute IoU between two boxes in (x1,y1,x2,y2) format."""
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    inter = max(0, xB - xA) * max(0, yB - yA)
    if inter == 0:
        return 0.0
    areaA = (boxA[2]-boxA[0]) * (boxA[3]-boxA[1])
    areaB = (boxB[2]-boxB[0]) * (boxB[3]-boxB[1])
    return inter / float(areaA + areaB - inter)


def apply_nms(detections):
    """
    Apply per-class NMS to raw YOLO detections.

    Input:  list of (label, conf, x1, y1, x2, y2)
    Output: filtered list with duplicate boxes removed.

    Each label is processed independently so a phone and a
    laptop that happen to overlap are never suppressed against
    each other.
    """
    # Group by label
    by_label: dict[str, list] = {}
    for det in detections:
        by_label.setdefault(det[0], []).append(det)

    kept = []
    for label, dets in by_label.items():
        # Sort highest confidence first
        dets = sorted(dets, key=lambda d: d[1], reverse=True)
        suppressed = [False] * len(dets)
        for i in range(len(dets)):
            if suppressed[i]:
                continue
            kept.append(dets[i])
            boxA = dets[i][2:]   # (x1,y1,x2,y2)
            for j in range(i+1, len(dets)):
                if suppressed[j]:
                    continue
                boxB = dets[j][2:]
                if _iou(boxA, boxB) > NMS_IOU_THRESHOLD:
                    suppressed[j] = True
    return kept


# ══════════════════════════════════════════════════════════════
#  OBJECT PERSISTENCE TRACKER
#
#  WHY: The simple detection_buffer dict counted frames but had
#  no concept of "is this the SAME object or a new detection?"
#  Problems with the old approach:
#   - A phone detected in the top-left on frame 10 and
#     bottom-right on frame 11 incremented the SAME counter,
#     even though they're different locations/objects.
#   - Counter never reset between separate appearances.
#   - No IoU-based continuity check.
#
#  HOW: For each confirmed detection (post-NMS), we maintain a
#  list of tracked objects per label. A new detection is matched
#  to an existing track if IoU >= TRACK_IOU_MIN. Matched tracks
#  get their hit_count incremented. Unmatched tracks decay.
#  A track is "confirmed" (triggers alert) when hit_count
#  reaches TRACK_CONFIRM_FRAMES. Once alerted, the track enters
#  cooldown so it doesn't re-alert until it disappears and
#  reappears. Tracks that haven't matched for TRACK_MAX_AGE
#  frames are removed.
# ══════════════════════════════════════════════════════════════

TRACK_IOU_MIN       = 0.25   # minimum IoU to match detection to existing track
TRACK_CONFIRM_FRAMES = 4     # frames before triggering a violation alert
TRACK_MAX_AGE       = 8      # frames of no match before track is deleted
TRACK_ALERT_COOLDOWN = 60    # frames between re-alerts for same track (~6s at 10fps)

class _Track:
    _id_counter = 0

    def __init__(self, label, conf, box):
        _Track._id_counter += 1
        self.track_id    = _Track._id_counter
        self.label       = label
        self.conf        = conf
        self.box         = box          # (x1,y1,x2,y2)
        self.hit_count   = 1
        self.age         = 0            # frames since last match
        self.alerted     = False        # has this track fired a violation?
        self.alert_cooldown = 0         # countdown frames until can re-alert

    def update(self, conf, box):
        self.conf  = conf
        self.box   = box
        self.hit_count += 1
        self.age   = 0
        if self.alert_cooldown > 0:
            self.alert_cooldown -= 1

    def is_confirmed(self):
        return self.hit_count >= TRACK_CONFIRM_FRAMES

    def can_alert(self):
        return self.is_confirmed() and self.alert_cooldown == 0

    def mark_alerted(self):
        self.alerted        = True
        self.alert_cooldown = TRACK_ALERT_COOLDOWN


class ObjectPersistenceTracker:
    """
    Maintains per-label track lists.
    Call update_tracks() each YOLO frame with post-NMS detections.
    Returns list of tracks that are newly confirmed and ready to alert.
    On non-YOLO frames, call tick() to age all tracks by one frame.
    """

    def __init__(self):
        # label → list of _Track
        self._tracks: dict[str, list] = {}

    def _get_tracks(self, label):
        return self._tracks.setdefault(label, [])

    def update_tracks(self, detections):
        """
        detections: list of (label, conf, x1, y1, x2, y2) post-NMS.
        Returns list of (label, conf, box) tuples that should fire alerts.
        """
        # Age all existing tracks — unmatched ones will be pruned below
        for tracks in self._tracks.values():
            for t in tracks:
                t.age += 1

        to_alert = []

        # Group detections by label for efficient matching
        by_label: dict[str, list] = {}
        for det in detections:
            by_label.setdefault(det[0], []).append(det)

        for label, dets in by_label.items():
            tracks = self._get_tracks(label)
            matched_track_ids = set()

            for (lbl, conf, x1, y1, x2, y2) in dets:
                box = (x1, y1, x2, y2)
                best_iou   = 0.0
                best_track = None

                for t in tracks:
                    iou = _iou(box, t.box)
                    if iou > best_iou:
                        best_iou   = iou
                        best_track = t

                if best_track and best_iou >= TRACK_IOU_MIN:
                    # Matched existing track
                    best_track.update(conf, box)
                    matched_track_ids.add(best_track.track_id)
                else:
                    # New object — create fresh track
                    new_track = _Track(label, conf, box)
                    tracks.append(new_track)
                    matched_track_ids.add(new_track.track_id)

                # Check for alert on this track
                for t in tracks:
                    if t.track_id in matched_track_ids and t.can_alert():
                        to_alert.append((t.label, t.conf, t.box))
                        t.mark_alerted()

        # Prune dead tracks (too old without a match)
        for label in list(self._tracks.keys()):
            self._tracks[label] = [
                t for t in self._tracks[label] if t.age <= TRACK_MAX_AGE
            ]

        return to_alert

    def tick(self):
        """Call on non-YOLO frames to passively age tracks."""
        for tracks in self._tracks.values():
            for t in tracks:
                t.age += 1
        # Prune dead tracks
        for label in list(self._tracks.keys()):
            self._tracks[label] = [
                t for t in self._tracks[label] if t.age <= TRACK_MAX_AGE
            ]

    def get_all_active(self):
        """Return all tracks with hit_count >= 1 for drawing on skipped frames."""
        active = []
        for tracks in self._tracks.values():
            for t in tracks:
                if t.age == 0 or t.hit_count >= 2:
                    active.append(t)
        return active


# ══════════════════════════════════════════════════════════════
#  THREADED VIDEO STREAM
#  Reads frames in a background thread so the main detection
#  loop never blocks waiting for cap.read().
# ══════════════════════════════════════════════════════════════

class VideoStream:
    def __init__(self, src: int = 0):
        self.cap = cv2.VideoCapture(src)
        if not self.cap.isOpened():
            raise RuntimeError(
                f"Cannot open camera {src}. "
                "Check webcam is connected and not used by another app."
            )
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS,          15)
        self.queue   = Queue(maxsize=3)
        self.stopped = False

    def start(self):
        threading.Thread(target=self._update, daemon=True).start()
        return self

    def _update(self):
        while not self.stopped:
            ret, frame = self.cap.read()
            if not ret:
                self.stopped = True
                break
            if self.queue.full():
                try:
                    self.queue.get_nowait()
                except Empty:
                    pass
            self.queue.put(frame)

    def read(self):
        try:
            return self.queue.get(timeout=2.0)
        except Empty:
            return None

    def stop(self):
        self.stopped = True
        self.cap.release()


# ══════════════════════════════════════════════════════════════
#  KALMAN FILTER  (smooths face bounding box over time)
# ══════════════════════════════════════════════════════════════

class KalmanFilter:
    def __init__(self):
        dt     = 1.0
        self.A = np.eye(8)
        for i in range(4):
            self.A[i, i + 4] = dt
        self.H = np.eye(4, 8)
        self.Q = np.eye(8) * 0.01
        self.R = np.eye(4) * 0.5
        self.P = np.eye(8) * 100
        self.x = np.zeros((8, 1))
        self.initialized = False

    def init(self, cx, cy, w, h):
        self.x = np.array([[cx],[cy],[w],[h],[0],[0],[0],[0]], dtype=float)
        self.initialized = True

    def predict(self):
        if not self.initialized:
            return None
        self.x = self.A @ self.x
        self.P = self.A @ self.P @ self.A.T + self.Q
        return self._state()

    def update(self, cx, cy, w, h):
        if not self.initialized:
            self.init(cx, cy, w, h)
            return self._state()
        z     = np.array([[cx],[cy],[w],[h]], dtype=float)
        y_vec = z - self.H @ self.x
        S     = self.H @ self.P @ self.H.T + self.R
        K     = self.P @ self.H.T @ inv(S)
        self.x = self.x + K @ y_vec
        self.P = (np.eye(8) - K @ self.H) @ self.P
        return self._state()

    def _state(self):
        return (int(self.x[0,0]), int(self.x[1,0]),
                int(self.x[2,0]), int(self.x[3,0]))


# ══════════════════════════════════════════════════════════════
#  MEDIAPIPE MODELS  (initialised once at import time)
# ══════════════════════════════════════════════════════════════

mp_face_detection = mp.solutions.face_detection
mp_face_mesh      = mp.solutions.face_mesh

face_detector = mp_face_detection.FaceDetection(
    model_selection=1, min_detection_confidence=0.3
)
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=False, max_num_faces=3,
    refine_landmarks=True,
    min_detection_confidence=0.3, min_tracking_confidence=0.3,
)
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))


# ══════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════

def apply_clahe(frame):
    lab     = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l       = clahe.apply(l)
    return cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)


def detect_faces(frame, rgb, fw, fh):
    all_faces = []
    det = face_detector.process(rgb)
    if det.detections:
        for d in det.detections:
            bb = d.location_data.relative_bounding_box
            x  = max(0, int(bb.xmin * fw))
            y  = max(0, int(bb.ymin * fh))
            bw = int(bb.width  * fw)
            bh = int(bb.height * fh)
            all_faces.append({'bbox':(x,y,bw,bh),'score':d.score[0],'method':'detection'})
    mesh = face_mesh.process(rgb)
    if mesh.multi_face_landmarks:
        for lms in mesh.multi_face_landmarks:
            xs  = [lm.x for lm in lms.landmark]
            ys  = [lm.y for lm in lms.landmark]
            pad = 20
            min_x = max(0,  int(min(xs)*fw) - pad)
            min_y = max(0,  int(min(ys)*fh) - pad)
            max_x = min(fw, int(max(xs)*fw) + pad)
            max_y = min(fh, int(max(ys)*fh) + pad)
            all_faces.append({'bbox':(min_x,min_y,max_x-min_x,max_y-min_y),
                              'score':0.85,'method':'mesh'})
    return all_faces


def is_valid_face(x, y, bw, bh, fw, fh, score, method):
    if method == 'mesh':
        return (bw >= 30 and bh >= 30), "mesh check"
    if score < 0.25:        return False, "low conf"
    if bw < 60 or bh < 60: return False, "too small"
    if bw > fw * 0.98:      return False, "too large"
    aspect = bw / max(bh, 1)
    if aspect < 0.25 or aspect > 2.5: return False, "wrong shape"
    cx = x + bw // 2
    if cx < fw*0.02 or cx > fw*0.98: return False, "edge"
    return True, "valid"


def remove_duplicates(faces):
    final = []
    for face in faces:
        x, y, bw, bh = face['bbox']
        dup = False
        for i, ex in enumerate(final):
            ex2, ey2, _, _ = ex['bbox']
            if abs(x-ex2) < 80 and abs(y-ey2) < 80:
                dup = True
                if face['score'] > ex['score']:
                    final[i] = face
                break
        if not dup:
            final.append(face)
    return final


def student(person_bbox, face_bboxes):
    px, py, pw, ph = person_bbox
    pw = pw - px
    ph = ph - py
    for face in face_bboxes:
        fx, fy, fw, fh = face
        if (px < fx+fw and px+pw > fx and py < fy+fh and py+ph > fy):
            overlap_w    = min(px+pw, fx+fw) - max(px, fx)
            overlap_h    = min(py+ph, fy+fh) - max(py, fy)
            overlap_area = overlap_w * overlap_h
            if overlap_area > fx*fh*0.3:
                return True
    return False


def make_evidence_saver(evidence_dir: str):
    path = os.path.abspath(evidence_dir)
    os.makedirs(path, exist_ok=True)
    last_ts   = {}
    cooldowns = {
        "no_face": 3.0, "multiple_faces": 3.0,
        "multiple_faces_persistent": 5.0, "talking": 3.0,
        "phone": 5.0, "laptop": 5.0, "bottle": 5.0,
        "book": 1.0, "manual": 1.0, "other_person": 5.0,
        "gaze_away": 5.0,
    }
    def save(tag: str, frame):
        now = time.time()
        if now - last_ts.get(tag, 0) < cooldowns.get(tag, 3.0):
            return
        last_ts[tag] = now
        filename = os.path.join(path, f"{tag}_{int(now)}.jpg")
        cv2.imwrite(filename, frame)
        print(f"  Evidence saved: {filename}")
    return save


# ══════════════════════════════════════════════════════════════
#  WARNING SYSTEM
#  add_warning() writes to shared memory so Flask can send
#  the violation to the browser overlay via /get-warnings.
#  Each violation type has its own cooldown to prevent spam.
# ══════════════════════════════════════════════════════════════

_warning_last_ts: dict = {}
_WARNING_COOLDOWNS = {
    "no_face": 5.0, "multiple_faces": 5.0, "other_person": 5.0,
    "phone": 8.0, "laptop": 8.0, "bottle": 8.0,
    "book": 8.0, "talking": 5.0, "gaze_away": 8.0,
}

def add_warning(violation_type: str, message: str):
    now      = time.time()
    cooldown = _WARNING_COOLDOWNS.get(violation_type, 5.0)
    if now - _warning_last_ts.get(violation_type, 0) < cooldown:
        return
    _warning_last_ts[violation_type] = now

    with shared.warning_lock:
        shared.warning_count += 1
        shared.warning_messages.append({
            "type":    violation_type,
            "message": message,
            "count":   shared.warning_count,
            "time":    time.strftime("%H:%M:%S")
        })
    print(f"  WARNING [{shared.warning_count}/5] — {violation_type}")


# ══════════════════════════════════════════════════════════════
#  DRAWING HELPERS
# ══════════════════════════════════════════════════════════════

def draw_label(frame, text, x, y, color, font_scale=0.55, thickness=2):
    font        = cv2.FONT_HERSHEY_SIMPLEX
    (tw, th), _ = cv2.getTextSize(text, font, font_scale, thickness)
    ly          = max(y - 10, th + 4)
    cv2.rectangle(frame, (x, ly-th-4), (x+tw+4, ly+2), color, -1)
    cv2.putText(frame, text, (x+2, ly-2), font, font_scale, (0,0,0), thickness)


def draw_status_panel(frame, status_text, status_color, face_count, fps, fw, fh):
    font    = cv2.FONT_HERSHEY_SIMPLEX
    overlay = frame.copy()
    cv2.rectangle(overlay, (0,0), (300,130), (20,20,20), -1)
    cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, frame)
    cv2.putText(frame, status_text,            (15, 38),  font, 0.8,  status_color,  2)
    cv2.putText(frame, f"Faces: {face_count}", (15, 72),  font, 0.6,  (255,255,255), 2)
    cv2.putText(frame, f"FPS: {fps:.1f}",      (15, 102), font, 0.55, (200,200,200), 1)


# ══════════════════════════════════════════════════════════════
#  MAIN DETECTION LOOP
#  Called by app.py in a background thread when the exam starts.
#  Writes processed frames into shared.output_frame every loop
#  so Flask's /video_feed can stream them to the browser.
#
#  OPTIMISATION CHANGES (3 changes to reduce load):
#  1. Camera warm-up reduced from 1.5s → 0.5s
#  2. CLAHE runs every 2nd frame only (not every frame)
#  3. YOLO runs every 3rd frame only (not every frame)
#     — face detection still runs every frame for smooth tracking
# ══════════════════════════════════════════════════════════════

def start_face_detection(stop_event=None, evidence_dir=None, event_queue=None):

    _evidence_dir = evidence_dir if evidence_dir is not None else EVIDENCE_DIR

    print("  Loading YOLO model …")
    yolo_model = YOLO(MODEL_NAME)
    print(f"  YOLO '{MODEL_NAME}' ready.")

    print(f"  Opening camera {CAMERA_INDEX} …")
    vs = VideoStream(CAMERA_INDEX).start()
    print("  Waiting for camera to warm up …")

    # CHANGE 1: reduced from 1.5s to 0.5s
    # Previously face.py waited 1.5 seconds after opening the camera.
    # Combined with the 2s delay in IT_quiz.html, that was 3.5s of
    # dead time before the student saw anything. 0.5s is enough.
    time.sleep(0.5)
    print("  Camera ready.\n")

    save_evidence      = make_evidence_saver(_evidence_dir)
    kf                 = KalmanFilter()
    kf_initialized     = False
    no_face_counter    = 0
    multi_face_counter = 0
    detection_buffer: dict[str, int] = {}   # kept for reference — replaced by tracker below
    prev_time          = time.time()
    fps                = 0.0
    gaze_tracker       = GazeTracker()
    gaze_away_counter  = 0

    # ── NMS + OBJECT PERSISTENCE TRACKER ─────────────────────
    # Replaces the simple detection_buffer dict.
    # Tracks each detected object across frames using IoU matching.
    obj_tracker        = ObjectPersistenceTracker()

    # CHANGE 2 & 3: frame counter added
    # Used to skip CLAHE and YOLO on alternate/every-3rd frames
    frame_count = 0

    # Store last YOLO results so we can reuse them on skipped frames
    last_yolo_results = []

    while True:
        if stop_event is not None and stop_event.is_set():
            break

        frame = vs.read()
        if frame is None:
            print("  Waiting for frame …")
            time.sleep(0.05)
            continue

        frame_count += 1
        fh, fw = frame.shape[:2]

        # CHANGE 2: CLAHE every 2nd frame only
        # CLAHE is colour enhancement for low light — it doesn't need
        # to run every single frame. Running it every other frame
        # saves meaningful CPU time with no visible quality difference.
        if frame_count % 2 == 0:
            enhanced = apply_clahe(frame)
        else:
            enhanced = frame

        rgb = cv2.cvtColor(enhanced, cv2.COLOR_BGR2RGB)

        # Face detection runs every frame — needed for smooth tracking
        all_faces   = detect_faces(enhanced, rgb, fw, fh)
        valid_faces = [f for f in all_faces
                    if is_valid_face(*f['bbox'], fw, fh, f['score'], f['method'])[0]]
        valid_faces = remove_duplicates(valid_faces)

        # ── MULTIPLE FACES ────────────────────────────────────
        if len(valid_faces) > 1:
            multi_face_counter += 1
            for face in valid_faces:
                x, y, bw, bh = face['bbox']
                cv2.rectangle(frame, (x,y), (x+bw,y+bh), (0,0,255), 3)
                cv2.putText(frame, "INTRUDER!", (x, max(y-10,20)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)
            if multi_face_counter >= MULTI_FACE_ALERT_FRAMES:
                add_warning("multiple_faces", "Multiple people detected in frame!")
                save_evidence("multiple_faces_persistent", frame)
        else:
            multi_face_counter = 0

        for face in valid_faces:
            x, y, bw, bh = face['bbox']
            dbg_color = (0,255,255) if face['method']=='mesh' else (255,255,0)
            cv2.rectangle(frame, (x,y), (x+bw,y+bh), dbg_color, 1)

        # ── KALMAN TRACKING ───────────────────────────────────
        if valid_faces:
            best = max(valid_faces, key=lambda f: f['score'])
            x, y, bw, bh = best['bbox']
            cx, cy = x+bw//2, y+bh//2
            if not kf_initialized:
                kf.init(cx, cy, bw, bh)
                kf_initialized = True
            else:
                kf.update(cx, cy, bw, bh)
            kf_cx, kf_cy, kf_w, kf_h = kf._state()
            dx = kf_cx - kf_w//2
            dy = kf_cy - kf_h//2
            cv2.rectangle(frame, (dx,dy), (dx+kf_w,dy+kf_h), (0,255,0), 2)
            cv2.putText(frame, f"FACE {best['score']:.2f}",
                        (dx, max(dy-8,14)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)
            no_face_counter = 0
        else:
            if kf_initialized:
                pred = kf.predict()
                if pred:
                    kf_cx, kf_cy, kf_w, kf_h = pred
                    dx = kf_cx - kf_w//2
                    dy = kf_cy - kf_h//2
                    for i in range(4):
                        cv2.rectangle(frame, (dx,dy+i*3), (dx+kf_w,dy+i*3+2), (0,255,255), 1)
                    cv2.putText(frame, "Predicting…", (dx, max(dy-8,14)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,255,255), 1)
            no_face_counter += 1

        # ── GAZE TRACKING ─────────────────────────────────────
        # Only run when we have a face AND the mesh returned iris data.
        # MediaPipe FaceMesh with refine_landmarks=True provides iris
        # landmarks (indices 468–477). We use them to estimate where
        # the student is looking relative to the screen centre.
        gaze_dir = "forward"
        if valid_faces:
            mesh = face_mesh.process(rgb)
            if mesh.multi_face_landmarks:
                # Use the first (primary) face only
                gaze_dir, looking_away = gaze_tracker.estimate(
                    mesh.multi_face_landmarks[0], fw, fh
                )
                if looking_away:
                    gaze_away_counter += 1
                else:
                    gaze_away_counter = 0

                if gaze_away_counter >= GAZE_AWAY_THRESHOLD:
                    add_warning("gaze_away",
                                f"Student looking {gaze_dir} — not at screen!")
                    save_evidence("gaze_away", frame)
                    gaze_away_counter = 0   # reset after warning

                # Draw gaze direction label on frame
                gaze_color = (0, 165, 255) if looking_away else (0, 255, 0)
                cv2.putText(frame, f"Gaze: {gaze_dir}",
                            (15, fh - 20), cv2.FONT_HERSHEY_SIMPLEX,
                            0.55, gaze_color, 2)
        else:
            gaze_away_counter = 0

        # ── YOLO OBJECT DETECTION ─────────────────────────────
        # YOLO runs every 3rd frame only (heavy operation).
        # On YOLO frames: run inference → apply NMS → feed tracker.
        # On skipped frames: tick the tracker to age tracks, then
        # redraw last confirmed boxes to avoid visual flicker.
        if frame_count % 3 == 0:
            last_yolo_results = []
            raw = yolo_model(frame, stream=True, conf=MIN_CONFIDENCE_THRESHOLD,
                            imgsz=IMAGE_SIZE, verbose=False)
            for r in raw:
                for box in r.boxes:
                    cls   = int(box.cls[0])
                    label = yolo_model.names[cls]
                    conf  = float(box.conf[0])
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    last_yolo_results.append((label, conf, x1, y1, x2, y2))

            # ── STEP 1: Filter to allowed objects only ────────
            filtered = [
                d for d in last_yolo_results if d[0] in ALLOWED_OBJECTS
            ]

            # ── STEP 2: Per-detection pre-filtering ──────────
            # (confidence threshold, area checks, bottle HSV)
            # This runs BEFORE NMS so NMS only sees valid candidates.
            pre_nms = []
            face_boxes = [f['bbox'] for f in valid_faces]
            for (label, conf, x1, y1, x2, y2) in filtered:

                if label == "person":
                    # Person boxes are handled separately below —
                    # keep them in a side list, not into NMS pipeline
                    if student((x1,y1,x2,y2), face_boxes):
                        cv2.rectangle(frame,(x1,y1),(x2,y2),(0,255,0),2)
                        draw_label(frame,f"student {conf:.2f}",x1,y1,(0,255,0))
                    else:
                        cv2.rectangle(frame,(x1,y1),(x2,y2),(0,0,255),3)
                        draw_label(frame,f"WARNING: OTHER PERSON {conf:.2f}",x1,y1,(0,0,255))
                        add_warning("other_person","Another person detected in frame!")
                        save_evidence("other_person", frame)
                    continue

                # Confidence gate
                if conf < ALLOWED_OBJECTS[label]:
                    if label == "bottle":
                        if not steel_bottle(frame, x1, y1, x2, y2):
                            continue
                    else:
                        continue

                # Laptop area sanity check (ignore a laptop that fills
                # >45% of the frame — probably the exam laptop itself)
                if label == "laptop":
                    area_ratio = ((x2-x1)*(y2-y1)) / max(fh*fw, 1)
                    if area_ratio > 0.45:
                        continue

                pre_nms.append((label, conf, x1, y1, x2, y2))

            # ── STEP 3: Apply NMS ─────────────────────────────
            # Removes redundant overlapping boxes for the same class.
            post_nms = apply_nms(pre_nms)

            # ── STEP 4: Feed persistence tracker ─────────────
            # Returns only tracks that have been confirmed across
            # TRACK_CONFIRM_FRAMES and are ready to fire an alert.
            to_alert = obj_tracker.update_tracks(post_nms)

            # ── STEP 5: Fire violation alerts ─────────────────
            for (label, conf, box) in to_alert:
                x1, y1, x2, y2 = box
                display = DISPLAY_NAMES.get(label, label.upper())
                color   = OBJ_COLORS.get(label, OBJ_COLORS["default"])
                cv2.rectangle(frame, (x1,y1), (x2,y2), color, 2)
                draw_label(frame, f"{display} {conf:.2f}", x1, y1, color)

                if label == "cell phone":
                    add_warning("phone", "Mobile phone detected!")
                    save_evidence("phone", frame)
                elif label == "laptop":
                    add_warning("laptop", "Laptop detected!")
                    save_evidence("laptop", frame)
                elif label == "bottle":
                    add_warning("bottle", "Unauthorized item detected!")
                    save_evidence("bottle", frame)
                elif label == "book":
                    add_warning("book", "Book detected!")
                    save_evidence("book", frame)
                elif label == "earphone":
                    add_warning("phone", "Earphone detected!")
                    save_evidence("phone", frame)

        else:
            # Non-YOLO frame: age all tracks by one frame
            obj_tracker.tick()

        # ── DRAW ALL ACTIVE TRACKED OBJECTS ───────────────────
        # Redraws confirmed boxes on every frame (YOLO and skipped)
        # so the display doesn't flicker between YOLO frames.
        for track in obj_tracker.get_all_active():
            if track.label == "person":
                continue   # person boxes drawn inline above
            if not track.is_confirmed():
                continue   # don't draw unconfirmed tracks
            x1, y1, x2, y2 = track.box
            display = DISPLAY_NAMES.get(track.label, track.label.upper())
            color   = OBJ_COLORS.get(track.label, OBJ_COLORS["default"])
            cv2.rectangle(frame, (x1,y1), (x2,y2), color, 2)
            draw_label(frame,
                    f"{display} {track.conf:.2f} [T{track.track_id}]",
                    x1, y1, color)

        # ── AUDIO EVENTS ──────────────────────────────────────
        if event_queue is not None:
            while True:
                try:
                    ev = event_queue.get_nowait()
                    if ev.get("type") == "talking":
                        add_warning("talking", "Talking / noise detected!")
                        save_evidence("talking", frame)
                        print("  Talking event — evidence saved.")
                except queue_module.Empty:
                    break
                except Exception:
                    break

        # ── NO FACE ───────────────────────────────────────────
        if len(valid_faces) > 1:
            save_evidence("multiple_faces", frame)
        if no_face_counter == NO_FACE_THRESHOLD:
            add_warning("no_face", "No face detected — are you still there?")
            save_evidence("no_face", frame)

        # ── STATUS PANEL ──────────────────────────────────────
        if no_face_counter >= NO_FACE_THRESHOLD:
            status, s_color = "WARNING: No face detected!", (0,0,255)
        elif len(valid_faces) == 0:
            status, s_color = "Detecting…", (0,165,255)
        elif len(valid_faces) == 1:
            status, s_color = "OK — Face detected", (0,255,0)
        else:
            status, s_color = f"CRITICAL: {len(valid_faces)} faces!", (0,0,255)

        now       = time.time()
        fps       = 0.9*fps + 0.1*(1.0/max(now-prev_time, 1e-9))
        prev_time = now

        draw_status_panel(frame, status, s_color, len(valid_faces), fps, fw, fh)

        # ── SHARE FRAME WITH FLASK ────────────────────────────
        with shared.frame_lock:
            shared.output_frame = frame.copy()

        time.sleep(0.01)

    # ── CLEANUP ───────────────────────────────────────────────
    if stop_event is not None:
        stop_event.set()
    vs.stop()
    cv2.destroyAllWindows()
    print("  Face detection stopped.")


def main():
    start_face_detection()

if __name__ == "__main__":
    main()